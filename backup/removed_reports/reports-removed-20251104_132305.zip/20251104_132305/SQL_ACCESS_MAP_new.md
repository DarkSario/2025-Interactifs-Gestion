======================================================================
Database Usage Audit Tool
======================================================================

Scanning directory: /home/runner/work/2025-Interactifs-Gestion/2025-Interactifs-Gestion
This may take a moment...

Generating SQL_ACCESS_MAP.md...
✓ Written to /home/runner/work/2025-Interactifs-Gestion/2025-Interactifs-Gestion/reports/SQL_ACCESS_MAP.md

Generating TODOs.md...
✓ Written to /home/runner/work/2025-Interactifs-Gestion/2025-Interactifs-Gestion/reports/TODOs.md

======================================================================
Audit Complete!
======================================================================

Summary:
  - row.get() issues found: 68
  - Direct sqlite3.connect() calls: 62
  - Total fetch patterns: 304

Review the reports in /home/runner/work/2025-Interactifs-Gestion/2025-Interactifs-Gestion/reports/ for details.

⚠️  CRITICAL issues found! See TODOs.md for action items.
